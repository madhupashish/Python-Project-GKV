A = ["1","2","3","4"]
box = 0
for i in range(9):
    box+=1

print(box)

print(A)