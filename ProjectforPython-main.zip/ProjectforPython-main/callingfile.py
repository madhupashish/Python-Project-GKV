import py_pdf

py_pdf.main()